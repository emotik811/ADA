
interface GeneradorVector<T> {
	public T[] nuevoVector(int tamano);
}

